#ifndef PROJ_2_SRC_V2_HEADERS_DELAY_H_
#define PROJ_2_SRC_V2_HEADERS_DELAY_H_ 1
extern int delay;
#endif  // PROJ_2_SRC_V2_HEADERS_DELAY_H_
