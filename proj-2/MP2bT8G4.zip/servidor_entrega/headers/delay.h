#ifndef HEADERS_DELAY_H_
#define HEADERS_DELAY_H_ 1
extern int delay;
#endif  // HEADERS_DELAY_H_
